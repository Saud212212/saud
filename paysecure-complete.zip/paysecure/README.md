# 🚀 PaySecure — دليل التشغيل الكامل

## 📁 هيكل المشروع

```
paysecure/
├── backend/
│   ├── server.js          ← الخادم الرئيسي (Node.js + Express)
│   ├── package.json       ← تبعيات المشروع
│   ├── .env.example       ← نموذج الإعدادات (انسخه إلى .env)
│   └── paysecure.db       ← قاعدة البيانات (تتولد تلقائياً)
└── frontend/
    └── public/
        ├── index.html     ← الواجهة الأمامية الكاملة
        ├── manifest.json  ← إعدادات PWA
        └── sw.js          ← Service Worker (تطبيق بدون إنترنت)
```

---

## ⚡ الخطوة ١: تجهيز الجهاز

```bash
# تأكد من تثبيت Node.js 18+
node --version

# إذا لم يكن مثبتاً:
# https://nodejs.org  ← حمّل LTS
```

---

## ⚡ الخطوة ٢: تثبيت المشروع

```bash
cd paysecure/backend
npm install
```

---

## ⚡ الخطوة ٣: إعداد Moyasar (مفاتيح الدفع)

### 1. سجّل حساب تاجر مجاناً:
👉 https://dashboard.moyasar.com/register

### 2. من لوحة التحكم اذهب إلى:
Settings → API Keys → انسخ المفاتيح

### 3. أنشئ ملف `.env`:
```bash
cp .env.example .env
```

### 4. عدّل ملف `.env`:
```
MOYASAR_SECRET_KEY=sk_live_XXXXXXXXXXXXXXXXXXXXXXXX
MOYASAR_PUBLISHABLE_KEY=pk_live_XXXXXXXXXXXXXXXXXXXXXXXX
WEBHOOK_SECRET=اختر_كلمة_سر_عشوائية
SUCCESS_URL=https://your-domain.com/payment/success
ERROR_URL=https://your-domain.com/payment/error
```

### 5. عدّل في `frontend/public/index.html` السطر:
```javascript
const PUBLISHABLE_KEY = 'pk_live_XXXXXXXXXXXXXXXXXXXXXXXX';
```

---

## ⚡ الخطوة ٤: تشغيل النظام محلياً

```bash
# من مجلد backend
npm start

# أو للتطوير (يعيد التشغيل تلقائياً عند التعديل)
npm run dev
```

✅ افتح المتصفح على: **http://localhost:3000**

---

## ⚡ الخطوة ٥: نشر النظام (الاستضافة)

### الخيار الأسرع — Vercel (مجاني):

```bash
# تثبيت Vercel CLI
npm i -g vercel

# من مجلد paysecure
vercel

# أضف متغيرات البيئة في:
# https://vercel.com → مشروعك → Settings → Environment Variables
```

### خيار بديل — Railway.app (مجاني جزئياً):
1. اذهب إلى https://railway.app
2. New Project → Deploy from GitHub
3. أضف Environment Variables
4. ✅ يشتغل تلقائياً!

---

## 📱 الخطوة ٦: تحويله تطبيق (PWA)

بمجرد رفع الموقع على HTTPS، يصبح تطبيق PWA تلقائياً:

- **Android:** سيظهر بانر "إضافة للشاشة الرئيسية" تلقائياً
- **iOS Safari:** اضغط زر المشاركة ← "إضافة للشاشة الرئيسية"

### الأيقونات المطلوبة (ضعها في `/icons/`):
```
icon-72.png
icon-96.png
icon-128.png
icon-144.png
icon-152.png
icon-192.png   ← الأهم
icon-384.png
icon-512.png   ← الأهم
```
يمكنك توليدها من: https://realfavicongenerator.net

---

## 📊 API Endpoints

| Endpoint | Method | الوصف |
|----------|--------|-------|
| `/api/orders` | POST | إنشاء طلب جديد |
| `/api/orders/:id` | GET | جلب تفاصيل طلب |
| `/api/payments/initiate` | POST | بدء عملية دفع |
| `/api/payments/:id/status` | GET | التحقق من حالة دفع |
| `/api/admin/stats` | GET | إحصائيات لوحة الإدارة |
| `/api/admin/orders` | GET | قائمة الطلبات |
| `/webhooks/moyasar` | POST | استقبال إشعارات Moyasar |

---

## 🔔 إعداد Webhooks في Moyasar

1. اذهب إلى: dashboard.moyasar.com → Webhooks
2. أضف: `https://your-domain.com/webhooks/moyasar`
3. اختر الأحداث: `payment.paid`, `payment.failed`
4. انسخ الـ Webhook Secret وأضفه للـ `.env`

---

## 🏪 نشره في App Store

### Android (Play Store) - الطريقة الأسهل:

```bash
npm install -g @bubblewrap/cli
bubblewrap init --manifest https://your-domain.com/manifest.json
bubblewrap build
```
سيولّد لك ملف `.apk` جاهز للرفع!

### iOS (App Store):
```bash
# تحتاج: Mac + Xcode + حساب Apple Developer ($99/سنة)
npm install -g @ionic/cli
ionic integrations enable capacitor
npx cap add ios
npx cap open ios
# ثم ارفع من Xcode
```

---

## 🧪 اختبار الدفع (وضع التجربة)

استخدم بيانات Moyasar التجريبية:
```
رقم البطاقة: 4111 1111 1111 1111
تاريخ الانتهاء: 12/25
CVV: 123
OTP: 1234
```

---

## 📞 الدعم والمساعدة

- Moyasar: support@moyasar.com | +966 11 XXX XXXX
- الوثائق: https://docs.moyasar.com
