/**
 * PaySecure Service Worker
 * يتيح عمل التطبيق بدون إنترنت ويسرّع التحميل
 */

const CACHE_NAME = 'paysecure-v1.0.0';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap',
];

// تثبيت الـ Service Worker وتخزين الملفات
self.addEventListener('install', (event) => {
  console.log('[SW] Installing PaySecure Service Worker...');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[SW] Caching static assets');
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

// تفعيل وحذف الـ Cache القديم
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating new Service Worker...');
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== CACHE_NAME)
          .map((key) => {
            console.log('[SW] Deleting old cache:', key);
            return caches.delete(key);
          })
      )
    )
  );
  self.clients.claim();
});

// استراتيجية الـ Cache: Network First للـ API، Cache First للـ Static
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // API calls: دائماً من الشبكة
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/webhooks/')) {
    event.respondWith(
      fetch(request).catch(() =>
        new Response(JSON.stringify({ error: 'لا يوجد اتصال بالإنترنت' }), {
          status: 503,
          headers: { 'Content-Type': 'application/json' },
        })
      )
    );
    return;
  }

  // Static assets: Cache First
  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request).then((response) => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
        }
        return response;
      });
    })
  );
});

// Push Notifications (اختياري - للإشعارات)
self.addEventListener('push', (event) => {
  if (!event.data) return;
  const data = event.data.json();
  
  event.waitUntil(
    self.registration.showNotification(data.title || 'PaySecure', {
      body: data.body || 'إشعار جديد',
      icon: '/icons/icon-192.png',
      badge: '/icons/icon-96.png',
      dir: 'rtl',
      lang: 'ar',
      data: { url: data.url || '/' },
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.openWindow(event.notification.data?.url || '/')
  );
});
