/**
 * PaySecure Backend - Node.js + Express
 * بوابة الدفع الآمنة - الخادم الرئيسي
 * 
 * يتضمن:
 *  - ربط Moyasar (بوابة دفع سعودية)
 *  - قاعدة بيانات SQLite (قابل للتبديل بـ MySQL/PostgreSQL)
 *  - نظام الطلبات والمدفوعات
 *  - Webhooks لاستقبال حالة الدفع
 *  - لوحة إدارة بسيطة
 */

const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ========================================
// ⚙️  الإعدادات - غيّر هذه القيم
// ========================================
const CONFIG = {
  MOYASAR_SECRET_KEY: process.env.MOYASAR_SECRET_KEY || 'sk_test_XXXXXXXXXXXXXXXXXXXXXXXX',
  MOYASAR_PUBLISHABLE_KEY: process.env.MOYASAR_PUBLISHABLE_KEY || 'pk_test_XXXXXXXXXXXXXXXXXXXXXXXX',
  MOYASAR_API: 'https://api.moyasar.com/v1',
  CURRENCY: 'SAR',
  STORE_NAME: 'متجري الإلكتروني',
  WEBHOOK_SECRET: process.env.WEBHOOK_SECRET || 'your_webhook_secret_here',
  SUCCESS_URL: process.env.SUCCESS_URL || 'http://localhost:3000/payment/success',
  ERROR_URL: process.env.ERROR_URL || 'http://localhost:3000/payment/error',
};

// ========================================
// 🗄️  قاعدة البيانات SQLite
// ========================================
const db = new Database('./paysecure.db');

// إنشاء الجداول
db.exec(`
  CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    amount INTEGER NOT NULL,
    currency TEXT DEFAULT 'SAR',
    description TEXT,
    customer_name TEXT,
    customer_email TEXT,
    customer_phone TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL,
    moyasar_id TEXT,
    amount INTEGER NOT NULL,
    currency TEXT DEFAULT 'SAR',
    method TEXT,
    status TEXT DEFAULT 'initiated',
    moyasar_response TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id)
  );

  CREATE TABLE IF NOT EXISTS webhooks_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT,
    payload TEXT,
    received_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// ========================================
// 🛠️  Middleware
// ========================================
app.use(cors({ origin: '*' }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend/public')));

// Helper: توليد ID فريد
function generateId(prefix = 'ORD') {
  return `${prefix}-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

// Helper: Moyasar API call
async function moyasarRequest(endpoint, method = 'GET', body = null) {
  const auth = Buffer.from(CONFIG.MOYASAR_SECRET_KEY + ':').toString('base64');
  const options = {
    method,
    headers: {
      'Authorization': `Basic ${auth}`,
      'Content-Type': 'application/json',
    },
  };
  if (body) options.body = JSON.stringify(body);
  
  const res = await fetch(`${CONFIG.MOYASAR_API}${endpoint}`, options);
  return res.json();
}

// ========================================
// 📦  API Routes - الطلبات
// ========================================

// إنشاء طلب جديد
app.post('/api/orders', (req, res) => {
  try {
    const { amount, description, customer } = req.body;

    if (!amount || amount < 100) {
      return res.status(400).json({ error: 'المبلغ غير صحيح (الحد الأدنى ١ ريال)' });
    }

    const orderId = generateId('ORD');
    db.prepare(`
      INSERT INTO orders (id, amount, currency, description, customer_name, customer_email, customer_phone)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      orderId,
      amount, // بالهللات: 25000 = 250 ريال
      CONFIG.CURRENCY,
      description || 'طلب شراء',
      customer?.name || '',
      customer?.email || '',
      customer?.phone || ''
    );

    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
    res.json({ success: true, order });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// جلب طلب
app.get('/api/orders/:id', (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'الطلب غير موجود' });
  
  const payments = db.prepare('SELECT * FROM payments WHERE order_id = ?').all(order.id);
  res.json({ order, payments });
});

// ========================================
// 💳  API Routes - المدفوعات (Moyasar)
// ========================================

// بدء عملية الدفع
app.post('/api/payments/initiate', async (req, res) => {
  try {
    const { order_id, method, token, save_card } = req.body;

    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(order_id);
    if (!order) return res.status(404).json({ error: 'الطلب غير موجود' });
    if (order.status === 'paid') return res.status(400).json({ error: 'تم دفع هذا الطلب مسبقاً' });

    const paymentId = generateId('PAY');

    // بناء طلب Moyasar
    const moyasarPayload = {
      amount: order.amount,
      currency: order.currency,
      description: order.description,
      publishable_api_key: CONFIG.MOYASAR_PUBLISHABLE_KEY,
      callback_url: `${CONFIG.SUCCESS_URL}?order_id=${order_id}`,
      metadata: {
        order_id: order_id,
        payment_id: paymentId,
        customer_name: order.customer_name,
      },
      source: {}
    };

    // اختيار طريقة الدفع
    if (method === 'creditcard') {
      moyasarPayload.source = { type: 'token', token };
    } else if (method === 'applepay') {
      moyasarPayload.source = { type: 'applepay', token };
    } else if (method === 'stcpay') {
      moyasarPayload.source = { type: 'stcpay', mobile: req.body.mobile };
    }

    // إرسال لـ Moyasar
    const moyasarRes = await moyasarRequest('/payments', 'POST', moyasarPayload);

    // حفظ في قاعدة البيانات
    db.prepare(`
      INSERT INTO payments (id, order_id, moyasar_id, amount, currency, method, status, moyasar_response)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      paymentId,
      order_id,
      moyasarRes.id || null,
      order.amount,
      order.currency,
      method,
      moyasarRes.status || 'initiated',
      JSON.stringify(moyasarRes)
    );

    // إذا نجح الدفع فوراً
    if (moyasarRes.status === 'paid') {
      db.prepare('UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
        .run('paid', order_id);
    }

    res.json({
      success: true,
      payment_id: paymentId,
      moyasar: moyasarRes,
      // إذا احتاج 3D Secure أو redirect
      redirect_url: moyasarRes.source?.transaction_url || null,
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// التحقق من حالة الدفع
app.get('/api/payments/:id/status', async (req, res) => {
  try {
    const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(req.params.id);
    if (!payment) return res.status(404).json({ error: 'الدفع غير موجود' });

    // تحديث من Moyasar إذا وجد ID
    if (payment.moyasar_id) {
      const moyasarRes = await moyasarRequest(`/payments/${payment.moyasar_id}`);
      
      if (moyasarRes.status !== payment.status) {
        db.prepare('UPDATE payments SET status = ?, moyasar_response = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
          .run(moyasarRes.status, JSON.stringify(moyasarRes), payment.id);
        
        if (moyasarRes.status === 'paid') {
          db.prepare('UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
            .run('paid', payment.order_id);
        }
        payment.status = moyasarRes.status;
      }
    }

    res.json({ payment });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ========================================
// 🔔  Webhook من Moyasar
// ========================================
app.post('/webhooks/moyasar', express.raw({ type: 'application/json' }), (req, res) => {
  try {
    const signature = req.headers['moyasar-signature'];
    const payload = req.body.toString();
    
    // التحقق من التوقيع (اختياري لكن مهم)
    const expectedSig = crypto
      .createHmac('sha256', CONFIG.WEBHOOK_SECRET)
      .update(payload)
      .digest('hex');

    // حفظ الـ webhook في السجل
    const event = JSON.parse(payload);
    db.prepare('INSERT INTO webhooks_log (event_type, payload) VALUES (?, ?)')
      .run(event.type || 'unknown', payload);

    // معالجة الأحداث
    if (event.type === 'payment_paid') {
      const moyasarId = event.data?.id;
      const payment = db.prepare('SELECT * FROM payments WHERE moyasar_id = ?').get(moyasarId);
      
      if (payment) {
        db.prepare('UPDATE payments SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
          .run('paid', payment.id);
        db.prepare('UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
          .run('paid', payment.order_id);
      }
    }

    res.json({ received: true });
  } catch (err) {
    console.error('Webhook error:', err);
    res.status(400).json({ error: err.message });
  }
});

// ========================================
// 📊  لوحة الإدارة API
// ========================================
app.get('/api/admin/stats', (req, res) => {
  const totalOrders = db.prepare('SELECT COUNT(*) as count FROM orders').get().count;
  const paidOrders = db.prepare("SELECT COUNT(*) as count FROM orders WHERE status = 'paid'").get().count;
  const totalRevenue = db.prepare("SELECT SUM(amount) as total FROM payments WHERE status = 'paid'").get().total || 0;
  const recentPayments = db.prepare('SELECT * FROM payments ORDER BY created_at DESC LIMIT 10').all();

  res.json({
    total_orders: totalOrders,
    paid_orders: paidOrders,
    pending_orders: totalOrders - paidOrders,
    total_revenue_halala: totalRevenue,
    total_revenue_sar: (totalRevenue / 100).toFixed(2),
    recent_payments: recentPayments,
    conversion_rate: totalOrders > 0 ? ((paidOrders / totalOrders) * 100).toFixed(1) + '%' : '0%',
  });
});

app.get('/api/admin/orders', (req, res) => {
  const { status, limit = 50, offset = 0 } = req.query;
  let query = 'SELECT * FROM orders';
  const params = [];
  
  if (status) { query += ' WHERE status = ?'; params.push(status); }
  query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  params.push(parseInt(limit), parseInt(offset));

  const orders = db.prepare(query).all(...params);
  res.json({ orders });
});

// ========================================
// 🌐  صفحة النجاح والخطأ
// ========================================
app.get('/payment/success', (req, res) => {
  const { order_id } = req.query;
  res.send(`
    <!DOCTYPE html><html lang="ar" dir="rtl">
    <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>تم الدفع بنجاح</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#f4f6f9;margin:0}
    .box{background:white;border-radius:20px;padding:40px;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,.08)}
    h1{color:#00c853}p{color:#607080}a{color:#009624}</style></head>
    <body><div class="box"><div style="font-size:60px">✅</div>
    <h1>تم الدفع بنجاح!</h1>
    <p>رقم الطلب: <strong>${order_id || 'N/A'}</strong></p>
    <a href="/">العودة للمتجر</a></div></body></html>
  `);
});

app.get('/payment/error', (req, res) => {
  res.send(`
    <!DOCTYPE html><html lang="ar" dir="rtl">
    <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>فشل الدفع</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#f4f6f9;margin:0}
    .box{background:white;border-radius:20px;padding:40px;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,.08)}
    h1{color:#e53935}p{color:#607080}a{color:#009624}</style></head>
    <body><div class="box"><div style="font-size:60px">❌</div>
    <h1>فشلت عملية الدفع</h1>
    <p>يرجى المحاولة مرة أخرى أو التواصل مع الدعم</p>
    <a href="/">المحاولة مجدداً</a></div></body></html>
  `);
});

// تشغيل الخادم
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════╗
║   PaySecure Backend Ready 🚀  ║
╠════════════════════════════════╣
║  Port:    http://localhost:${PORT}  ║
║  DB:      paysecure.db        ║
║  Moyasar: ${CONFIG.MOYASAR_SECRET_KEY.includes('test') ? 'TEST MODE 🟡' : 'LIVE MODE 🟢'}      ║
╚════════════════════════════════╝
  `);
});

module.exports = app;
